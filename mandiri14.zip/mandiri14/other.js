function demo2(){
    return "hello world my name is selom2";
}

function demo3(){
    return "hello world my name is selom3";
}

export { demo2,demo3}