import demo1 from "./source.js";
import {demo2,demo3} from "./other.js";

function test(){
    let first = demo1();
    let second = demo2();
    let third = demo3();
    document.querySelector(".demo").innerHTML = first + "<br/>" + second + "<br/>" + third;
}

test();