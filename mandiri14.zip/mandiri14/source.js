function demo1(){
    return "hello world my name is selom";
}

export default demo1;